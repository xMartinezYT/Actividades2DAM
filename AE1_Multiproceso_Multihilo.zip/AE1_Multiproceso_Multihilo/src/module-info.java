/**
 * 
 */
/**
 * 
 */
module AE1_Multiproceso_Multihilo {
	requires java.desktop;
}