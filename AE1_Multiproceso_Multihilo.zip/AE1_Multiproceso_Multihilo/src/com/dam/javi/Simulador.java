package com.dam.javi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.*;

import java.util.List;


/**
 * Clase que ejecuta todo el programa.
 * Implementa la interfaz que el usuario va a controlar..
 */


public class Simulador extends JFrame {

    /** Campos de texto para ingresar las cantidades de proteínas de cada tipo. */
    private JTextField[] cantidadProteinas = new JTextField[4];
    /** Área de texto para mostrar los resultados de las simulaciones. */
    private JTextArea resultadosArea;

    /**
     * Constructor de la clase Simulador.
     * Inicializa la ventana y los componentes de la interfaz gráfica.
     */
    public Simulador() {
        setTitle("Simulador de Proteínas");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        inicializarComponentes();
    }

    /**
     * Inicializa los componentes de la interfaz gráfica.
     * Crea los campos de entrada para las cantidades de proteínas y los botones de acción.
     */
    private void inicializarComponentes() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        JLabel[] labels = new JLabel[4];
        for (int i = 0; i < 4; i++) {
            labels[i] = new JLabel("Cantidad de proteínas tipo " + (i + 1) + ":");
            cantidadProteinas[i] = new JTextField("0");
            panel.add(labels[i]);
            panel.add(cantidadProteinas[i]);
        }

        JButton btnSimular = new JButton("Iniciar Simulación");
        btnSimular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarSimulaciones();
            }
        });

        panel.add(btnSimular);

        resultadosArea = new JTextArea();
        resultadosArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultadosArea);
        scrollPane.setPreferredSize(new Dimension(550, 200));

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    /**
     * Inicia las simulaciones en modo multiproceso y multihilo.
     * Limpia los archivos previos, ejecuta las simulaciones y muestra los tiempos totales en la interfaz.
     */
    private void iniciarSimulaciones() {
        int[] cantidades = new int[4];
        for (int i = 0; i < 4; i++) {
            cantidades[i] = Integer.parseInt(cantidadProteinas[i].getText());
        }

        resultadosArea.setText("");

        
        limpiarArchivosPrevios();

        long inicioMP = System.currentTimeMillis();
        try {
            realizarSimulacionMultiproceso(cantidades);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        long finMP = System.currentTimeMillis();
        double tiempoTotalMP = (finMP - inicioMP) / 1000.0;

        resultadosArea.append("Tiempo total Simulación Multiproceso: " + String.format("%.2f", tiempoTotalMP) + " segundos\n");

      
        long inicioMT = System.currentTimeMillis();
        try {
            realizarSimulacionMultihilo(cantidades);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        long finMT = System.currentTimeMillis();
        double tiempoTotalMT = (finMT - inicioMT) / 1000.0;

        resultadosArea.append("Tiempo total Simulación Multihilo: " + String.format("%.2f", tiempoTotalMT) + " segundos\n");
    }

    /**
     * Limpia los archivos de simulación generados en la ejecución anterior.
     * Elimina todos los archivos que coincidan con el patrón 'PROT_*.sim'.
     */
    private void limpiarArchivosPrevios() {
        File directorio = new File(".");
        File[] archivos = directorio.listFiles((dir, name) -> name.startsWith("PROT_") && name.endsWith(".sim"));

        if (archivos != null) {
            for (File archivo : archivos) {
                if (archivo.delete()) {
                    System.out.println("Archivo eliminado: " + archivo.getName());
                } else {
                    System.out.println("No se pudo eliminar el archivo: " + archivo.getName());
                }
            }
        }
    }

    /**
     * Realiza la simulación multiproceso.
     * Crea y ejecuta procesos independientes para cada simulación de proteína.
     *
     * @param cantidades Arreglo con las cantidades de proteínas de cada tipo a simular.
     * @throws IOException          Si ocurre un error de entrada/salida al iniciar los procesos.
     * @throws InterruptedException Si la ejecución de un proceso es interrumpida.
     */
    private void realizarSimulacionMultiproceso(int[] cantidades) throws IOException, InterruptedException {
        int contador = 1;
        List<Process> procesos = new java.util.ArrayList<>();
        String classpath = "bin" + File.pathSeparator + System.getProperty("java.class.path");
        for (int tipo = 1; tipo <= 4; tipo++) {
            for (int i = 0; i < cantidades[tipo - 1]; i++) {
                ProcessBuilder pb = new ProcessBuilder(
                    "java",
                    "-cp", classpath,
                    "com.dam.javi.SimulacionMP",
                    String.valueOf(tipo),
                    String.valueOf(contador)
                );
                pb.redirectErrorStream(true);
                Process process = pb.start();

                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("SimulacionMP Output: " + line);
                }

                procesos.add(process);
                contador++;
            }
        }
       
        
        for (Process process : procesos) {
            process.waitFor();
        }
    }

    /**
     * Realiza la simulación multihilo.
     * Crea y ejecuta hilos para cada simulación de proteína.
     *
     * @param cantidades Arreglo con las cantidades de proteínas de cada tipo a simular.
     * @throws InterruptedException Si la ejecución de un hilo es interrumpida.
     */
    private void realizarSimulacionMultihilo(int[] cantidades) throws InterruptedException {
        int contador = 1;
        List<Thread> hilos = new java.util.ArrayList<>();
        for (int tipo = 1; tipo <= 4; tipo++) {
            for (int i = 0; i < cantidades[tipo - 1]; i++) {
                Thread hilo = new Thread(new SimulacionMT(tipo, contador));
                hilos.add(hilo);
                hilo.start();
                contador++;
            }
        }
     
        
        for (Thread hilo : hilos) {
            hilo.join();
        }
    }

    /**
     * Método principal que inicia la aplicación.
     * Crea una instancia de la clase Simulador y la muestra.
     *
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Simulador simulador = new Simulador();
            simulador.setVisible(true);
        });
    }
}
