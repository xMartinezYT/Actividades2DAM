package com.dam.javi;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase que representa una simulación multihilo de proteínas.
 * Implementa la interfaz Runnable para permitir su ejecución en un hilo separado.
 */
public class SimulacionMT implements Runnable {

    /** Tipo de proteína a simular. */
    private int tipo;
    /** Orden de la proteína dentro del total de simulaciones. */
    private int orden;

    /**
     * Constructor de la clase SimulacionMT.
     *
     * @param tipo  Tipo de proteína a simular.
     * @param orden Orden de la proteína dentro del total de simulaciones.
     */
    public SimulacionMT(int tipo, int orden) {
        this.tipo = tipo;
        this.orden = orden;
    }

    /**
     * Método que ejecuta la simulación de la proteína.
     * Se encarga de calcular la simulación, medir tiempos y generar el archivo de salida.
     */
    @Override
    public void run() {
        String simulationType = "MT";

        String startTimeStamp = getCurrentTimeStamp();

        long startTimeMillis = System.currentTimeMillis();

        double result = simulation(tipo);

        long endTimeMillis = System.currentTimeMillis();

        String endTimeStamp = getCurrentTimeStamp();

        double duration = (endTimeMillis - startTimeMillis) / 1000.0;
        String durationStr = formatDuration(duration);

        String fileName = String.format("PROT_%s_%d_n%d_%s.sim", simulationType, tipo, orden, startTimeStamp);

        synchronized (SimulacionMT.class) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                writer.write(startTimeStamp);
                writer.newLine();
                writer.write(endTimeStamp);
                writer.newLine();
                writer.write(durationStr);
                writer.newLine();
                writer.write(String.valueOf(result));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Realiza la simulación de la proteína según el tipo especificado.
     *
     * @param type Tipo de proteína a simular.
     * @return Resultado del cálculo de la simulación.
     */
    public static double simulation(int type) {
        double calc = 0.0;
        double simulationTime = Math.pow(5, type);
        double startTime = System.currentTimeMillis();
        double endTime = startTime + simulationTime;
        while (System.currentTimeMillis() < endTime) {
            calc = Math.sin(Math.pow(Math.random(), 2));
        }
        return calc;
    }

    /**
     * Obtiene la marca de tiempo actual en el formato 'AÑOMESDÍA_HORAMINUTOSEGUNDO_CENTÉSIMAS'.
     *
     * @return Cadena con la marca de tiempo formateada.
     */
    public static String getCurrentTimeStamp() {
        Date now = new Date();
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd_HHmmss");
        SimpleDateFormat sdfMillis = new SimpleDateFormat("SSS");
        String datePart = sdfDate.format(now);
        String millisPart = sdfMillis.format(now);
        String centesimas = millisPart.substring(0, 2);
        return datePart + "_" + centesimas;
    }

    /**
     * Formatea la duración en segundos y centésimas, separados por guión bajo.
     *
     * @param duration Duración en segundos.
     * @return Cadena con la duración formateada como 'SEGUNDOS_CENTÉSIMAS'.
     */
    public static String formatDuration(double duration) {
        int segundos = (int) duration;
        int centesimas = (int) ((duration - segundos) * 100);
        return segundos + "_" + centesimas;
    }
}