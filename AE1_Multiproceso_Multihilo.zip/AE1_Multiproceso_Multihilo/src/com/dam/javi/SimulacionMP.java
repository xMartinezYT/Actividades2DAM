package com.dam.javi;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase que representa una simulación multiproceso de proteínas.
 * Esta clase se ejecuta como un proceso independiente y realiza la simulación de una proteína específica.
 */
public class SimulacionMP {

    /**
     * Método principal que inicia la simulación multiproceso.
     *
     * @param args Argumentos de línea de comandos. Deben incluir:
     *             <ul>
     *               <li>args[0]: Tipo de proteína a simular.</li>
     *               <li>args[1]: Orden de la proteína dentro del total de simulaciones.</li>
     *             </ul>
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Uso: java SimulacionMP <tipo> <orden>");
            return;
        }

        int tipo = Integer.parseInt(args[0]);
        int orden = Integer.parseInt(args[1]);

        String simulationType = "MP";

        String startTimeStamp = getCurrentTimeStamp();

        long startTimeMillis = System.currentTimeMillis();

        double result = simulation(tipo);

        long endTimeMillis = System.currentTimeMillis();

        String endTimeStamp = getCurrentTimeStamp();

        double duration = (endTimeMillis - startTimeMillis) / 1000.0;
        String durationStr = formatDuration(duration);

        String fileName = String.format("PROT_%s_%d_n%d_%s.sim", simulationType, tipo, orden, startTimeStamp);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(startTimeStamp);
            writer.newLine();
            writer.write(endTimeStamp);
            writer.newLine();
            writer.write(durationStr);
            writer.newLine();
            writer.write(String.valueOf(result));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Realiza la simulación de la proteína según el tipo especificado.
     *
     * @param type Tipo de proteína a simular.
     * @return Resultado del cálculo de la simulación.
     */
    public static double simulation(int type) {
        double calc = 0.0;
        double simulationTime = Math.pow(5, type);
        double startTime = System.currentTimeMillis();
        double endTime = startTime + simulationTime;
        while (System.currentTimeMillis() < endTime) {
            calc = Math.sin(Math.pow(Math.random(), 2));
        }
        return calc;
    }

    /**
     * Obtiene la marca de tiempo actual en el formato 'AÑOMESDÍA_HORAMINUTOSEGUNDO_CENTÉSIMAS'.
     *
     * @return Cadena con la marca de tiempo formateada.
     */
    public static String getCurrentTimeStamp() {
        Date now = new Date();
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd_HHmmss");
        SimpleDateFormat sdfMillis = new SimpleDateFormat("SSS");
        String datePart = sdfDate.format(now);
        String millisPart = sdfMillis.format(now);
        String centesimas = millisPart.substring(0, 2); // Obtener las centésimas de segundo
        return datePart + "_" + centesimas;
    }

    /**
     * Formatea la duración en segundos y centésimas, separados por guión bajo.
     *
     * @param duration Duración en segundos.
     * @return Cadena con la duración formateada como 'SEGUNDOS_CENTÉSIMAS'.
     */
    public static String formatDuration(double duration) {
        int segundos = (int) duration;
        int centesimas = (int) ((duration - segundos) * 100);
        return segundos + "_" + centesimas;
    }
}
