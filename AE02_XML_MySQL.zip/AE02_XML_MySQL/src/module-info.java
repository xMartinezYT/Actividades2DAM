/**
 * 
 */
/**
 * 
 */
module AE02_XML_MySQL {
	requires java.desktop;
    requires java.sql;
}