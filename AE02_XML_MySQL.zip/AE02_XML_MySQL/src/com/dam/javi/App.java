package com.dam.javi;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.List;

/**
 * Aplicación de gestión de Base de Datos con interfaz gráfica.
 */
public class App extends JFrame {
    private JTextField txtUsuario, campoConsulta, campoNuevoUsuario, campoNuevaContraseña;
    private JTextField campoConsulta_1;
    private JPasswordField txtContraseña;
    private JTable tablaResultadosCliente, tablaResultadosAdministrador;
    private DefaultTableModel modeloTablaCliente, modeloTablaAdministrador;
    private Connection conexion;
    private CardLayout diseñoTarjeta;
    private String rolUsuarioActual;
    private JTextArea areaContenidoXml;

    /**
     * Método principal para iniciar la aplicación.
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                App frame = new App();
                frame.setVisible(true);
                frame.setSize(900, 800); // Ajuste del tamaño de la ventana
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Constructor de la clase App.
     */
    public App() {
        setTitle("Gestión de Base de Datos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 800);

        diseñoTarjeta = new CardLayout();
        getContentPane().setLayout(diseñoTarjeta);

        JPanel panel_login = new JPanel(null);
        JPanel panel_cliente = new JPanel(null);
        JPanel panel_administrador = new JPanel(null);

        configurarPanelLogin(panel_login);
        configurarPanelCliente(panel_cliente);
        configurarPanelAdministrador(panel_administrador);

        getContentPane().add(panel_login, "login");
        getContentPane().add(panel_cliente, "client");
        getContentPane().add(panel_administrador, "admin");

        diseñoTarjeta.show(getContentPane(), "login");
    }

    /**
     * Configura el panel de inicio de sesión.
     * @param panel_login Panel de inicio de sesión.
     */
    private void configurarPanelLogin(JPanel panel_login) {
        JLabel lblUser = new JLabel("Usuario:");
        lblUser.setBounds(350, 200, 200, 25);
        panel_login.add(lblUser);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(350, 230, 200, 25);
        panel_login.add(txtUsuario);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(350, 260, 200, 25);
        panel_login.add(lblPassword);

        txtContraseña = new JPasswordField();
        txtContraseña.setBounds(350, 290, 200, 25);
        panel_login.add(txtContraseña);

        JButton btnLogin = new JButton("Entrar");
        btnLogin.setBounds(375, 330, 150, 30);
        panel_login.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String nombreUsuario = txtUsuario.getText();
            String contraseña = new String(txtContraseña.getPassword());

            try {
                if (conexion == null || conexion.isClosed()) {
                    conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/population", nombreUsuario, contraseña);
                }

                if (validarUsuarioPorPrivilegios(nombreUsuario, contraseña)) {
                    if (rolUsuarioActual.equals("admin")) {
                        diseñoTarjeta.show(getContentPane(), "admin");
                    } else {
                        diseñoTarjeta.show(getContentPane(), "client");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al conectar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /**
     * Valida el usuario según sus privilegios.
     * @param nombreUsuario Nombre de usuario.
     * @param contraseña Contraseña del usuario.
     * @return true si la validación es exitosa, false en caso contrario.
     */
    private boolean validarUsuarioPorPrivilegios(String nombreUsuario, String contraseña) {
        String consulta = "SELECT password, type FROM users WHERE login = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(consulta)) {
            stmt.setString(1, nombreUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String hashContraseñaAlmacenada = rs.getString("password");
                String tipo = rs.getString("type");

                if (verifyPassword(contraseña, hashContraseñaAlmacenada)) {
                    rolUsuarioActual = tipo;
                    return true;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    /**
     * Verifica si la contraseña proporcionada coincide con el hash almacenado.
     * @param contraseña Contraseña proporcionada.
     * @param storedHash Hash almacenado.
     * @return true si coinciden, false en caso contrario.
     */
    private boolean verifyPassword(String contraseña, String storedHash) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytesHash = md.digest(contraseña.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytesHash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString().equals(storedHash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Configura el panel para clientes.
     * @param panel_cliente Panel de clientes.
     */
    private void configurarPanelCliente(JPanel panel_cliente) {
        JLabel lblQuery = new JLabel("Introduce tu consulta SQL (SELECT):");
        lblQuery.setBounds(50, 50, 400, 25);
        panel_cliente.add(lblQuery);

        campoConsulta_1 = new JTextField();
        campoConsulta_1.setBounds(50, 80, 600, 25);
        panel_cliente.add(campoConsulta_1);

        JButton btnExecuteQuery = new JButton("Ejecutar Consulta");
        btnExecuteQuery.setBounds(670, 80, 150, 30);
        panel_cliente.add(btnExecuteQuery);

        modeloTablaCliente = new DefaultTableModel();
        tablaResultadosCliente = new JTable(modeloTablaCliente);
        JScrollPane scrollPane = new JScrollPane(tablaResultadosCliente);
        scrollPane.setBounds(50, 130, 800, 300);
        panel_cliente.add(scrollPane);

        btnExecuteQuery.addActionListener(e -> ejecutarConsultaCliente());

        JButton btnExportCSV = new JButton("Exportar a CSV");
        btnExportCSV.setBounds(50, 450, 150, 30);
        panel_cliente.add(btnExportCSV);

        btnExportCSV.addActionListener(e -> exportarCSVCliente());

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(700, 450, 150, 30);
        panel_cliente.add(btnLogout);

        btnLogout.addActionListener(e -> {
            try {
                if (conexion != null) {
                    conexion.close();
                    conexion = null;
                }
                diseñoTarjeta.show(getContentPane(), "login");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al cerrar sesión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /**
     * Configura el panel para administradores.
     * @param panel_administrador Panel de administradores.
     */
    private void configurarPanelAdministrador(JPanel panel_administrador) {
        JLabel lblQuery = new JLabel("Introduce tu consulta SQL (SELECT):");
        lblQuery.setBounds(345, 101, 280, 30);
        panel_administrador.add(lblQuery);

        campoConsulta = new JTextField();
        lblQuery.setLabelFor(campoConsulta);
        campoConsulta.setBounds(156, 132, 600, 25);
        panel_administrador.add(campoConsulta);

        JButton btnExecuteQuery = new JButton("Ejecutar Consulta");
        btnExecuteQuery.setBounds(244, 479, 150, 30);
        panel_administrador.add(btnExecuteQuery);

        modeloTablaAdministrador = new DefaultTableModel();
        tablaResultadosAdministrador = new JTable(modeloTablaAdministrador);
        JScrollPane scrollPane = new JScrollPane(tablaResultadosAdministrador);
        scrollPane.setBounds(47, 168, 800, 300);
        panel_administrador.add(scrollPane);

        btnExecuteQuery.addActionListener(e -> ejecutarConsultaAdministrador());

        JLabel lblNewUser = new JLabel("Nuevo Usuario:");
        lblNewUser.setBounds(52, 33, 94, 25);
        panel_administrador.add(lblNewUser);

        campoNuevoUsuario = new JTextField();
        campoNuevoUsuario.setBounds(156, 33, 200, 25);
        panel_administrador.add(campoNuevoUsuario);

        JLabel lblNewPassword = new JLabel("Contraseña:");
        lblNewPassword.setBounds(62, 69, 80, 25);
        panel_administrador.add(lblNewPassword);

        campoNuevaContraseña = new JTextField();
        campoNuevaContraseña.setBounds(156, 69, 200, 25);
        panel_administrador.add(campoNuevaContraseña);

        JButton btnAddUser = new JButton("Añadir Usuario");
        btnAddUser.setBounds(394, 60, 150, 30);
        panel_administrador.add(btnAddUser);

        btnAddUser.addActionListener(e -> crearNuevoUsuario());

        areaContenidoXml = new JTextArea();
        areaContenidoXml.setEditable(false);
        JScrollPane xmlScrollPane = new JScrollPane(areaContenidoXml);
        xmlScrollPane.setBounds(50, 520, 800, 100);
        panel_administrador.add(xmlScrollPane);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(731, 675, 150, 30);
        panel_administrador.add(btnLogout);

        JButton btnExportCSV = new JButton("Exportar a CSV");
        btnExportCSV.setBounds(540, 479, 150, 30);
        panel_administrador.add(btnExportCSV);

        btnExportCSV.addActionListener(e -> exportarCSVAdministrador());

        btnLogout.addActionListener(e -> {
            try {
                if (conexion != null) {
                    conexion.close();
                    conexion = null;
                }
                diseñoTarjeta.show(getContentPane(), "login");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al cerrar sesión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnImportCSV = new JButton("Importar CSV");
        btnImportCSV.setBounds(382, 640, 150, 30);
        panel_administrador.add(btnImportCSV);

        btnImportCSV.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Archivos CSV", "csv"));
            int seleccion = fileChooser.showOpenDialog(this);

            if (seleccion == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    importarCSV(file);
                } catch (IOException | SQLException e1) {
                    e1.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al importar CSV: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    /**
     * Ejecuta la consulta SQL proporcionada por el cliente, permitiendo solo consultas a la tabla 'population'.
     */
    private void ejecutarConsultaCliente() {
        String consultaOriginal = campoConsulta_1.getText();
        String consulta = consultaOriginal.toLowerCase().trim();

        // Validar que la consulta sea una SELECT
        if (!consulta.startsWith("select")) {
            JOptionPane.showMessageDialog(this, "Solo se permiten consultas SELECT.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validar que solo se acceda a la tabla 'population'
        if (!consulta.contains("from population")) {
            JOptionPane.showMessageDialog(this, "Solo se permite acceder a la tabla 'population'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Statement stmt = conexion.createStatement()) {
            ResultSet rs = stmt.executeQuery(consultaOriginal);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnas = rsmd.getColumnCount();
            modeloTablaCliente.setColumnCount(0);
            modeloTablaCliente.setRowCount(0);

            for (int i = 1; i <= columnas; i++) {
                modeloTablaCliente.addColumn(rsmd.getColumnLabel(i));
            }

            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int i = 1; i <= columnas; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                modeloTablaCliente.addRow(fila);
            }
            modeloTablaCliente.fireTableDataChanged();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al ejecutar consulta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Ejecuta la consulta SQL proporcionada por el administrador.
     */
    private void ejecutarConsultaAdministrador() {
        String consulta = campoConsulta.getText();
        try (Statement stmt = conexion.createStatement()) {
            ResultSet rs = stmt.executeQuery(consulta);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnas = rsmd.getColumnCount();
            modeloTablaAdministrador.setColumnCount(0);
            modeloTablaAdministrador.setRowCount(0);

            for (int i = 1; i <= columnas; i++) {
                modeloTablaAdministrador.addColumn(rsmd.getColumnLabel(i));
            }

            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int i = 1; i <= columnas; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                modeloTablaAdministrador.addRow(fila);
            }
            modeloTablaAdministrador.fireTableDataChanged();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al ejecutar consulta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Exporta los datos de la tabla del cliente a un archivo CSV.
     */
    private void exportarCSVCliente() {
        exportarCSV(modeloTablaCliente);
    }

    /**
     * Exporta los datos de la tabla del administrador a un archivo CSV.
     */
    private void exportarCSVAdministrador() {
        exportarCSV(modeloTablaAdministrador);
    }

    /**
     * Exporta los datos de una tabla a un archivo CSV.
     * @param modeloTabla Modelo de la tabla a exportar.
     */
    private void exportarCSV(DefaultTableModel modeloTabla) {
        try {
            JFileChooser fileChooser = new JFileChooser();
            int seleccion = fileChooser.showSaveDialog(this);

            if (seleccion == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();

                if (file != null) {
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                        for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
                            writer.write(modeloTabla.getColumnName(i));
                            if (i < modeloTabla.getColumnCount() - 1) {
                                writer.write(",");
                            }
                        }
                        writer.newLine();

                        for (int row = 0; row < modeloTabla.getRowCount(); row++) {
                            for (int col = 0; col < modeloTabla.getColumnCount(); col++) {
                                Object value = modeloTabla.getValueAt(row, col);
                                writer.write(value != null ? value.toString() : "");
                                if (col < modeloTabla.getColumnCount() - 1) {
                                    writer.write(",");
                                }
                            }
                            writer.newLine();
                        }
                    }

                    JOptionPane.showMessageDialog(this, "CSV exportado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al exportar CSV: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Crea un nuevo usuario en la base de datos.
     */
    private void crearNuevoUsuario() {
        String nombreUsuario = campoNuevoUsuario.getText();
        String contraseña = campoNuevaContraseña.getText();
        String hashedPassword = hashPassword(contraseña);

        try {
            String consulta = "INSERT INTO users (login, password, type) VALUES (?, ?, 'user')";
            try (PreparedStatement stmt = conexion.prepareStatement(consulta)) {
                stmt.setString(1, nombreUsuario);
                stmt.setString(2, hashedPassword);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Usuario creado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al crear usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Importa datos desde un archivo CSV y los inserta en la base de datos.
     * También muestra el contenido XML en el área de texto.
     * @param file Archivo CSV a importar.
     * @throws IOException Excepción de E/S.
     * @throws SQLException Excepción de SQL.
     */
    private void importarCSV(File file) throws IOException, SQLException {
        if (!file.exists() || !file.isFile()) {
            throw new IllegalArgumentException("Archivo no válido.");
        }

        List<String> lines = Files.readAllLines(file.toPath());
        if (lines.isEmpty()) throw new IllegalArgumentException("El archivo CSV está vacío.");

        String[] headers = lines.get(0).split(";");
        if (headers.length == 0) throw new IllegalArgumentException("No se encontraron encabezados en el archivo.");

        String tableName = "population";
        String createQuery = generarConsultaCreacion(headers, tableName);

        try (Statement stmt = conexion.createStatement()) {
            stmt.execute("DROP TABLE IF EXISTS " + tableName);
            stmt.execute(createQuery);
        }

        String insertQuery = generarConsultaInsercion(headers, tableName);

        String xmlDirectory = "xml";
        File xmlDir = new File(xmlDirectory);
        if (!xmlDir.exists()) xmlDir.mkdir();

        StringBuilder allXmlContent = new StringBuilder();

        try (PreparedStatement pstmt = conexion.prepareStatement(insertQuery)) {
            for (int i = 1; i < lines.size(); i++) {
                String[] values = procesarLineaCSV(lines.get(i).split(";"));
                if (values.length != headers.length) continue;

                String country = values[0];
                crearArchivoXML(xmlDirectory, country, headers, values);

                allXmlContent.append(leerContenidoXML(xmlDirectory + "/" + country + ".xml")).append("\n");

                for (int j = 0; j < values.length; j++) {
                    pstmt.setString(j + 1, values[j]);
                }
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }

        // Mostrar el contenido XML en el área de texto
        areaContenidoXml.setText(allXmlContent.toString());

        JOptionPane.showMessageDialog(null, "Importación completa. Archivos XML creados en el directorio: " + xmlDirectory);
    }

    /**
     * Genera la consulta SQL para crear una tabla.
     * @param headers Encabezados de la tabla.
     * @param tableName Nombre de la tabla.
     * @return Consulta SQL para crear la tabla.
     */
    private String generarConsultaCreacion(String[] headers, String tableName) {
        StringBuilder createQuery = new StringBuilder("CREATE TABLE IF NOT EXISTS " + tableName + " (");
        for (String header : headers) {
            createQuery.append(header.trim().replaceAll("[^a-zA-Z0-9_]", "_")).append(" VARCHAR(255),");
        }
        createQuery.deleteCharAt(createQuery.length() - 1).append(")");
        return createQuery.toString();
    }

    /**
     * Genera la consulta SQL para insertar datos en la tabla.
     * @param headers Encabezados de la tabla.
     * @param tableName Nombre de la tabla.
     * @return Consulta SQL para insertar datos.
     */
    private String generarConsultaInsercion(String[] headers, String tableName) {
        String params = String.join(",", "?".repeat(headers.length).split(""));
        return "INSERT INTO " + tableName + " VALUES (" + params + ")";
    }

    /**
     * Crea un archivo XML para cada registro.
     * @param directory Directorio donde se guardará el archivo XML.
     * @param country Nombre del país.
     * @param headers Encabezados del archivo CSV.
     * @param values Valores del registro.
     * @throws IOException Excepción de E/S.
     */
    private void crearArchivoXML(String directory, String country, String[] headers, String[] values) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(directory + "/" + country + ".xml"))) {
            writer.write("<" + country + ">\n");
            for (int i = 0; i < headers.length; i++) {
                writer.write("  <" + headers[i].trim() + ">" + values[i] + "</" + headers[i].trim() + ">\n");
            }
            writer.write("</" + country + ">");
        }
    }

    /**
     * Lee el contenido de un archivo XML.
     * @param filePath Ruta del archivo XML.
     * @return Contenido del archivo XML.
     * @throws IOException Excepción de E/S.
     */
    private String leerContenidoXML(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        List<String> lines = Files.readAllLines(Paths.get(filePath));
        for (String line : lines) {
            content.append(line).append("\n");
        }
        return content.toString();
    }

    /**
     * Procesa una línea del archivo CSV.
     * @param values Valores de la línea CSV.
     * @return Valores procesados.
     */
    private String[] procesarLineaCSV(String[] values) {
        for (int i = 0; i < values.length; i++) {
            values[i] = values[i].trim();

            if (values[i].matches(".*\\d,\\d.*")) {
                values[i] = values[i].replace(",", ".");
            }

            if (values[i].equalsIgnoreCase("N.A.") || values[i].isEmpty()) {
                values[i] = null;
            }

            if (values[i] != null && values[i].contains("%")) {
                values[i] = values[i].replace("%", "").trim();
            }
        }
        return values;
    }

    /**
     * Genera el hash de una contraseña utilizando SHA-256.
     * @param contraseña Contraseña a hashear.
     * @return Hash de la contraseña.
     */
    private String hashPassword(String contraseña) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytesHash = md.digest(contraseña.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytesHash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
