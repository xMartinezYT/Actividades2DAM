package javi.com.dam;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JTree;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultTreeModel;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class Vista extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;  
    private JTree tree;  
    private JScrollPane scrollPane;  
    private DefaultMutableTreeNode root;  
    private File directorio;  
    private String textoBusqueda;  
    private String textoReemplazo;  
    private boolean caseSensitive;  
    private boolean accentSensitive;  
    
    

    // Método principal para ejecutar la aplicación gráfica
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Vista frame = new Vista();  // Creamos la ventana principal
                    frame.setVisible(true);  // Hacemos visible la ventana
                } catch (Exception e) {
                    e.printStackTrace();  // Imprimir errores si ocurren
                }
            }
        });
    }

    
    // Constructor de la ventana principal
    public Vista() {
        setTitle("Gestión de Archivos");  // Título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Cerrar la ventana al salir
        setBounds(100, 100, 1107, 665);  // Tamaño y posición de la ventana
        contentPane = new JPanel();  // Panel principal donde añadimos componentes
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));  // Márgenes
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Lógica para seleccionar el directorio a analizar
        directorio = seleccionDirectorio();

        // Pedimos al usuario la cadena de búsqueda
        textoBusqueda = JOptionPane.showInputDialog(this, "Ingrese la cadena de texto a buscar:");
        if (textoBusqueda == null || textoBusqueda.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se ingresó ninguna cadena de texto.");
            System.exit(0);
        }

        // Pedimos al usuario la cadena de reemplazo
        textoReemplazo = JOptionPane.showInputDialog(this, "Ingrese la cadena de texto de reemplazo:");
        if (textoReemplazo == null) {
            JOptionPane.showMessageDialog(this, "No se ingresó ninguna cadena de reemplazo.");
            System.exit(0);
        }

        // Preguntamos si debe diferenciar entre mayúsculas y minúsculas
        int opcionMayusculas = JOptionPane.showConfirmDialog(
                this,
                "¿Desea que la búsqueda distinga entre mayúsculas y minúsculas?",
                "Sensibilidad de mayúsculas/minúsculas",
                JOptionPane.YES_NO_OPTION);
        caseSensitive = (opcionMayusculas == JOptionPane.YES_OPTION);

        // Preguntamos si debe diferenciar entre acentos
        int opcionAcentos = JOptionPane.showConfirmDialog(
                this,
                "¿Desea que la búsqueda distinga entre acentos?",
                "Sensibilidad de acentos",
                JOptionPane.YES_NO_OPTION);
        accentSensitive = (opcionAcentos == JOptionPane.YES_OPTION);

        
        
        // Configuramos la raíz del árbol con el nombre del directorio
        root = new DefaultMutableTreeNode(directorio.getName());

        // Configuramos el componente del árbol para mostrar la estructura de archivos
        tree = new JTree(root);
        scrollPane = new JScrollPane(tree);
        scrollPane.setBounds(50, 80, 1000, 450);
        contentPane.add(scrollPane);

        // Etiqueta que describe lo que se está mostrando
        JLabel lblNewLabel = new JLabel("Directorio desglosado con coincidencias y reemplazos");
        lblNewLabel.setBounds(342, 29, 487, 30);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        contentPane.add(lblNewLabel);

        // Botón para actualizar los resultados de la búsqueda y reemplazo
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(500, 550, 120, 30);
        contentPane.add(btnActualizar);

        // Acción cuando se presiona el botón de "Actualizar"
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarInformacion();  // Actualiza la información mostrada en el árbol
            }
        });

        // Ejecutamos la búsqueda y reemplazo al inicio
        actualizarInformacion();
    }

    // Método para actualizar la información del directorio y los reemplazos
    private void actualizarInformacion() {
        root.removeAllChildren();  // Limpiar el árbol antes de actualizarlo
        createNodes(root, directorio, textoBusqueda, textoReemplazo, caseSensitive, accentSensitive);
        
        // Actualizamos la vista del árbol
        DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
        model.reload();  // Refrescar el árbol
    }

    // Método recursivo que recorre los archivos y carpetas, busca coincidencias y realiza reemplazos
    private void createNodes(DefaultMutableTreeNode node, File file, String textoBusqueda, String textoReemplazo,
            boolean caseSensitive, boolean accentSensitive) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        if (file.isDirectory()) {  // Si es un directorio, recorremos su contenido
            File[] fList = file.listFiles();
            if (fList != null) {
                for (File f : fList) {
                    String name = f.getName();
                    long size = f.length();
                    String lastModified = sdf.format(new Date(f.lastModified()));
                    int coincidencias = 0;
                    int reemplazos = 0;

                    if (f.isFile()) {  // Si es un archivo, buscamos coincidencias y hacemos reemplazos
                        if (esTextoPlano(f)) {
                            coincidencias = contarCoincidencias(f, textoBusqueda, caseSensitive, accentSensitive);
                            if (coincidencias > 0) {
                                reemplazos = reemplazarTexto(f, textoBusqueda, textoReemplazo, caseSensitive, accentSensitive);
                            }
                        } else if (esPDF(f)) {  // Si es un PDF, contamos coincidencias pero no reemplazamos
                            coincidencias = contarCoincidenciasEnPDF(f, textoBusqueda, caseSensitive, accentSensitive);
                        }
                    }

                    // Añadimos la información al árbol
                    String nodeName = String.format("%s [Tamaño: %d bytes | Modificado: %s] (%d coincidencias, %d reemplazos)",
                            name, size, lastModified, coincidencias, reemplazos);

                    DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(nodeName);
                    node.add(childNode);

                    if (f.isDirectory()) {  // Si es un directorio, lo recorremos de forma recursiva
                        createNodes(childNode, f, textoBusqueda, textoReemplazo, caseSensitive, accentSensitive);
                    }
                }
            }
        } else if (file.isFile()) {  // Caso especial si es un archivo directamente
            String name = file.getName();
            long size = file.length();
            String lastModified = sdf.format(new Date(file.lastModified()));
            int coincidencias = 0;
            int reemplazos = 0;

            if (esTextoPlano(file)) {  // Si es un archivo de texto plano
                coincidencias = contarCoincidencias(file, textoBusqueda, caseSensitive, accentSensitive);
                if (coincidencias > 0) {
                    reemplazos = reemplazarTexto(file, textoBusqueda, textoReemplazo, caseSensitive, accentSensitive);
                }
            } else if (esPDF(file)) {  // Si es un archivo PDF
                coincidencias = contarCoincidenciasEnPDF(file, textoBusqueda, caseSensitive, accentSensitive);
            }

            // Añadimos el archivo al árbol
            String nodeName = String.format("%s [Tamaño: %d bytes | Modificado: %s] (%d coincidencias, %d reemplazos)",
                    name, size, lastModified, coincidencias, reemplazos);

            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(nodeName);
            node.add(childNode);
        }
    }

    
    
    // Método que determina si un archivo es de texto plano, comprobando su extensión
    private boolean esTextoPlano(File file) {
        String[] extensionesTexto = { ".txt", ".java", ".csv", ".html", ".xml", ".json", ".md", ".log" };
        String nombreArchivo = file.getName().toLowerCase();

        for (String ext : extensionesTexto) {
            if (nombreArchivo.endsWith(ext)) {
                return true;  // Devuelve true si el archivo es de texto
            }
        }
        return false;  // Devuelve false si no es de texto
    }

    
    // Método que determina si un archivo es un PDF, comprobando su extensión
    private boolean esPDF(File file) {
        return file.getName().toLowerCase().endsWith(".pdf");  // Devuelve true si es un PDF
    }

     // Método para contar las coincidencias en archivos de texto
    private int contarCoincidencias(File file, String textoBusqueda, boolean caseSensitive, boolean accentSensitive) {
        int count = 0;
        try {
            // Leer el contenido del archivo
            String contenido = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            String contenidoComparar = contenido;
            String textoComparar = textoBusqueda;

            // Ajustar el caso y los acentos según la configuración del usuario
            if (!caseSensitive) {
                contenidoComparar = contenidoComparar.toLowerCase();
                textoComparar = textoComparar.toLowerCase();
            }

            if (!accentSensitive) {
                contenidoComparar = eliminarAcentos(contenidoComparar);
                textoComparar = eliminarAcentos(textoComparar);
            }

            // Contar las coincidencias de la cadena de búsqueda en el archivo
            int index = 0;
            while ((index = contenidoComparar.indexOf(textoComparar, index)) != -1) {
                count++;
                index += textoComparar.length();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return count;
    }

    // Método para contar las coincidencias en archivos PDF
    private int contarCoincidenciasEnPDF(File file, String textoBusqueda, boolean caseSensitive, boolean accentSensitive) {
        int count = 0;
        try (PDDocument document = Loader.loadPDF(file)) {
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String contenido = pdfStripper.getText(document);

            String contenidoComparar = contenido;
            String textoComparar = textoBusqueda;

            // Ajustar el caso y los acentos según la configuración del usuario
            if (!caseSensitive) {
                contenidoComparar = contenidoComparar.toLowerCase();
                textoComparar = textoComparar.toLowerCase();
            }

            if (!accentSensitive) {
                contenidoComparar = eliminarAcentos(contenidoComparar);
                textoComparar = eliminarAcentos(textoComparar);
            }

            // Contar las coincidencias de la cadena de búsqueda en el PDF
            int index = 0;
            while ((index = contenidoComparar.indexOf(textoComparar, index)) != -1) {
                count++;
                index += textoComparar.length();
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "No se pudo acceder al archivo PDF: " + file.getName(),
                    "Error de acceso", JOptionPane.ERROR_MESSAGE);
        }
        return count;
    }

    
    // Método que realiza el reemplazo de texto en archivos de texto plano
    private int reemplazarTexto(File file, String textoBusqueda, String textoReemplazo, boolean caseSensitive,
            boolean accentSensitive) {
    int count = 0;  // Variable para contar el número de reemplazos
    try {
        // Leer el contenido del archivo
        String contenido = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        String contenidoOriginal = contenido;  // Guardamos el contenido original antes de cualquier modificación
        String textoComparar = textoBusqueda;  // Guardamos el texto a comparar

        // Ajustar caso (mayúsculas/minúsculas) según la configuración del usuario
        if (!caseSensitive) {
            contenidoOriginal = contenidoOriginal.toLowerCase();
            textoComparar = textoComparar.toLowerCase();
        }

        // Ajustar acentos según la configuración del usuario
        if (!accentSensitive) {
            contenidoOriginal = eliminarAcentos(contenidoOriginal);
            textoComparar = eliminarAcentos(textoComparar);
        }

        // Contar cuántas veces aparece la cadena de búsqueda
        count = contarOcurrencias(contenidoOriginal, textoComparar);

        // Si hay al menos una coincidencia, procedemos al reemplazo
        if (count > 0) {
            // Reemplazar la cadena de búsqueda por la cadena de reemplazo en el contenido original
            String contenidoModificado = contenido.replace(textoBusqueda, textoReemplazo);

            // Crear un nuevo archivo con el prefijo "MOD_"
            File nuevoArchivo = new File(file.getParent(), "MOD_" + file.getName());

            // Escribir el contenido modificado en el nuevo archivo
            Files.write(nuevoArchivo.toPath(), contenidoModificado.getBytes(StandardCharsets.UTF_8));

            // Mostrar un mensaje informativo si se ha creado el archivo
            System.out.println("Archivo modificado creado: " + nuevoArchivo.getAbsolutePath());
        } else {
            // Si no hay coincidencias, mostrar un mensaje informativo
            System.out.println("No se encontraron coincidencias en el archivo: " + file.getName());
        }

    } catch (IOException e) {
        // En caso de error, mostramos un mensaje
        JOptionPane.showMessageDialog(this, "No se pudo acceder al archivo: " + file.getName(), "Error de acceso", JOptionPane.ERROR_MESSAGE);
    }

    return count;  
}

    private int contarOcurrencias(String contenido, String textoComparar) {
    int count = 0;  
    int index = 0;

 
    while ((index = contenido.indexOf(textoComparar, index)) != -1) {
        count++;  
        index += textoComparar.length();  
    }

    return count;  
}


    // Método que elimina los acentos de una cadena de texto
    private String eliminarAcentos(String texto) {
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return texto;
    }

    // Método que abre un diálogo para seleccionar un directorio
    private File seleccionDirectorio() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Seleccion de directorio");
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int seleccion = fc.showOpenDialog(this);
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            return fc.getSelectedFile();
        } else {
            JOptionPane.showMessageDialog(this, "No se seleccionó ningún directorio.");
            System.exit(0);
        }
        return null;
    }
}
